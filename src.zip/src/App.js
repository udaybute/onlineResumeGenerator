import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Home from './components/Home';
import UserDetails from './components/userdetails/UserDetails';
import Experience from './components/userdetails/Experience';
import Education from './components/userdetails/Education';
import Skills from './components/userdetails/Skills';
import Project from './components/userdetails/Project';
import Template from './components/userdetails/Template';

function App() {
  return (
    <div className="App">
      <Router>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/userdetails" element={<UserDetails />} />
          <Route path="/experince" element={<Experience />} />
          <Route path="/education" element={<Education />} />
          <Route path="/skills" element={<Skills />} />
          <Route path="/projects" element={<Project />} />
          <Route path="/template" element={<Template />} />

        </Routes>
      </Router>
    </div>
  );
}

export default App;