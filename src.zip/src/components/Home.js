import React from 'react'
import {Link} from 'react-router-dom'
import "../components/Home.css";
import p1 from "../images/p1.png"
const Home = () => {
    return (
        <div>

            <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
                <div class="container-fluid">
                    <a class="navbar-brand" href="#">Make Resume Online</a>
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                            <li class="nav-item">
                                <a class="nav-link active" aria-current="page" href="#">Home</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </nav>


            <div className='containerbody '>
                <div className='d-flex'>
                    <div className='Heading mt-2'>
                        <h1>Free Resume Builder Create a Professional Resume Online</h1>
                        <span className='text-primary'>Free to use. Developed by hiring professionals</span>
                        <p>Hassle-free resume maker that can help you land your dream job in any industry. Trusted by job seekers and HR experts. Build your resume quickly and easily today.</p>
                        <br />
                        <h3>Make your resume fast</h3>
                        <p>Build your resume fast and easily with our online resume builder. It's packed with professional templates and step-by-step assistance. Just pick a template, and we'll guide you through the whole process with our expert tips. Making a resume has never been easier.</p>

                        <Link to="/userdetails" class="button-71" >Get Started </Link>
                    </div>
                    <div className='HeadingImg mt-2'>
                        <img src={p1} className='img-fluid w-100' />
                    </div>
                </div>
            </div>






        </div>
    )
}

export default Home