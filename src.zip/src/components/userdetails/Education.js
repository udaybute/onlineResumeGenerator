import React from 'react';
import { Link } from 'react-router-dom';
import '../Home.css';

const Education = () => {
  const [educationForms, setEducationForms] = React.useState([1]);

  const addEducationForm = () => {
    setEducationForms(prevForms => [...prevForms, prevForms.length + 1]);
  };

  return (
    <div className="containerbody w-100">
      

      {educationForms.map((formIndex) => (
        <div className="box1 w-75 m-auto border border-2 p-5" key={formIndex}>
          <h2>Education details {formIndex}</h2>
          <div className="row mb-4">
            <div className="col">
              <div className="form-outline">
                <input type="text" id={`form6Example1-${formIndex}`} className="form-control" />
                <label className="form-label" htmlFor={`form6Example1-${formIndex}`}>Degree</label>
              </div>
            </div>
            <div className="col">
              <div className="form-outline">
                <input type="text" id={`form6Example2-${formIndex}`} className="form-control" />
                <label className="form-label" htmlFor={`form6Example2-${formIndex}`}>School/University</label>
              </div>
            </div>
          </div>

          <div className="row mb-4">
            <div className="col">
              <div className="form-outline">
                <input type="date" id={`form6Example3-${formIndex}`} className="form-control" />
                <label className="form-label" htmlFor={`form6Example3-${formIndex}`}>Start Date</label>
              </div>
            </div>
            <div className="col">
              <div className="form-outline">
                <input type="date" id={`form6Example4-${formIndex}`} className="form-control" />
                <label className="form-label" htmlFor={`form6Example4-${formIndex}`}>End Date</label>
              </div>
            </div>
          </div>

          <div className="form-outline mb-4">
            <input type="text" id={`form6Example5-${formIndex}`} className="form-control" />
            <label className="form-label" htmlFor={`form6Example5-${formIndex}`}>City</label>
          </div>

          <div className="form-outline mb-4">
            <textarea className="form-control" id={`form6Example6-${formIndex}`} rows="4"></textarea>
            <label className="form-label" htmlFor={`form6Example6-${formIndex}`}>Description</label>
          </div>
        </div>
      ))}
<div className="d-flex justify-content-center align-items-center">
        <div className="box2">
          <button className="plus-button" onClick={addEducationForm}>+</button>
        </div>
      </div>
      <div className="d-flex justify-content-center">
        <div>
          <Link to="/experience" className="button-71 m-2">Previous</Link>
          <Link to="/skills" className="button-71 m-2">Next</Link>
        </div>
      </div>
    </div>
  );
}

export default Education;