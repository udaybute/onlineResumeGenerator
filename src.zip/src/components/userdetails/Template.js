import React from 'react'

const Template = () => {
  return (
    <div>Template</div>
  )
}

export default Template