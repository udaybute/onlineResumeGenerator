import React from 'react'
import { Link } from 'react-router-dom';
import "../Home.css";

const Experience = () => {
    
    return (
        <div className='containerbody '>
            <form className='w-75 m-auto mt-5 border-2'>
                <h1>Experience Details</h1>
                <div class="row mb-4">
                    <div class="col">
                        <div class="form-outline">
                            <input type="text" id="form6Example1" class="form-control" />
                            <label class="form-label" for="form6Example1">Company Name</label>
                        </div>
                    </div>
                    <div class="col">
                        <div class="form-outline">
                            <input type="text" id="form6Example2" class="form-control" />
                            <label class="form-label" for="form6Example2">Joning month</label>
                        </div>
                    </div>
                </div>

                <div class="form-outline mb-4">
                    <input type="text" id="form6Example3" class="form-control" />
                    <label class="form-label" for="form6Example3">Last Working Month</label>
                </div>

                <div class="form-outline mb-4">
                    <textarea class="form-control" id="form6Example7" rows="4"></textarea>
                    <label class="form-label" for="form6Example7">Project Details</label>
                </div>

                <div class="form-outline mb-4">
                    <input type="email" id="form6Example5" class="form-control" />
                    <label class="form-label" for="form6Example5">Technology use</label>
                </div>

                <div class="form-outline mb-4">
                    <input type="number" id="form6Example6" class="form-control" />
                    <label class="form-label" for="form6Example6">Project span in number of months</label>
                </div>

                

                <div className='d-flex'>
                    <Link to="/userdetails" className="button-71 m-2" >Previous</Link>
                    <Link to="/education" class="button-71 m-2" >Next</Link>
                </div>

                   </form>
        </div>
    )
}

export default Experience