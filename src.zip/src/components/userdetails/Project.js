import React from 'react'
import { Link } from 'react-router-dom';
import "../Home.css";
const Project = () => {
  return (
    <div className='containerbody '>
            <form className='w-75 m-auto mt-5 border-2'>
                <h1>Project Details</h1>
                <div class="row mb-4">
                    <div class="col">
                        <div class="form-outline">
                            <input type="text" id="form6Example1" class="form-control" />
                            <label class="form-label" for="form6Example1">First name</label>
                        </div>
                    </div>
                    <div class="col">
                        <div class="form-outline">
                            <input type="text" id="form6Example2" class="form-control" />
                            <label class="form-label" for="form6Example2">Last name</label>
                        </div>
                    </div>
                </div>

                <div class="form-outline mb-4">
                    <input type="text" id="form6Example3" class="form-control" />
                    <label class="form-label" for="form6Example3">Company name</label>
                </div>

                <div class="form-outline mb-4">
                    <input type="text" id="form6Example4" class="form-control" />
                    <label class="form-label" for="form6Example4">Address</label>
                </div>
                <div class="form-outline mb-4">
                    <input type="email" id="form6Example5" class="form-control" />
                    <label class="form-label" for="form6Example5">Email</label>
                </div>

                <div class="form-outline mb-4">
                    <input type="number" id="form6Example6" class="form-control" />
                    <label class="form-label" for="form6Example6">Phone</label>
                </div>

                <div class="form-outline mb-4">
                    <textarea class="form-control" id="form6Example7" rows="4"></textarea>
                    <label class="form-label" for="form6Example7">Additional information</label>
                </div>

                <div className='d-flex'>
                    <Link to="/projects" className="button-71 m-2" >Previous</Link>
                    <Link to="/template" class="button-71 m-2" >Next</Link>
                </div>

                   </form>
        </div>
  )
}

export default Project